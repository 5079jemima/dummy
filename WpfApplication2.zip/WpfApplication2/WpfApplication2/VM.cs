﻿using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;

namespace WpfApplication2
{
    [POCOViewModel]
   public class VM
    {
        public virtual List<string> ListofString { get; set; }

        BackgroundWorker worker;
        protected VM()
        {
            ListofString = new List<string>();

            ListofString.Add("1");
            ListofString.Add("2");
            ListofString.Add("3");
            ListofString.Add("4");

            worker = new BackgroundWorker();
            worker.DoWork += Worker_DoWork;
            worker.RunWorkerAsync();
        }

        private void Worker_DoWork(object sender, DoWorkEventArgs e)
        {
            int k = 0;
           while(true)
            {
                ListofString[0] += k.ToString();
                ListofString[1] += k.ToString();
                ListofString[2] += k.ToString();
                ListofString[3] += k.ToString();

                k++;
                this.RaisePropertyChanged(x => x.ListofString);
                Thread.Sleep(1000);
            }


        }

        public static VM Create()
        {
            return ViewModelSource.Create(() => new VM());
        }
    }
}
